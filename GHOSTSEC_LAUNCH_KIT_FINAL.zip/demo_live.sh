#!/bin/bash
echo 'Démo IA GhostSec en cours...'
